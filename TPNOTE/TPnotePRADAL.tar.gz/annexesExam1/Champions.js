function deleteElement(x){
  console.log("Entrée dans la fct deleteElement");

  let list = document.getElementById("mySelect");

  //parcours la liste
  for(let child of list){
    if (child.value == x.value) {
      list.removeChild(child);
      return;
    }
  }
}

function ajouterJoueur(){
	console.log("Entrée dans la fct ajouterJoueur");

	//Récupère un nom et l'ajoute à la liste
	let ajout = document.getElementById("nomArtAjout").value;
	let node = document.createElement("option");
	let textnode = document.createTextNode(ajout);
	node.appendChild(textnode);
	document.getElementById("mySelect").appendChild(node);
}

function supprimerJoueur() {
	console.log("Entrée dans la fct supprimerJoueur");

  //Récupère le nom du joueur
  let art = document.getElementById("nomArtSup");

  //Supprime le joueur
  deleteElement(art);
 }

function afficherDetails(){
  let winner = document.getElementById('mySelect');   //sélectionne l'élément en cours
	if (winner.value == "Robert Pires") {
		document.getElementById("winnerIS").setAttribute("src", "img/robert.jpg");
		document.getElementById("infos").textContent = winner.value+" né le 30 décembre à Paris";
	}
	else if (winner.value == "Kylian Mbappé") {
		document.getElementById("winnerIS").setAttribute("src", "img/kiki.jpg");
		document.getElementById("infos").textContent = winner.value+" né le 26 décembre à Toulouse";

	}
	else if (winner.value == "Antoine Griezmann") {
		document.getElementById("winnerIS").setAttribute("src", "img/antoine.jpg");
		document.getElementById("infos").textContent = winner.value+" né le 14 février à Paris";

	}
	else if (winner.value == "Cristiano Ronaldo") {
		document.getElementById("winnerIS").setAttribute("src", "img/cr7.jpg");
		document.getElementById("infos").textContent = winner.value+" né le 1 janvier à Toulon";

	}
	else {
		document.getElementById("winnerIS").setAttribute("src", "img/alea.jpeg");
		document.getElementById("infos").textContent = winner.value+" pas d'informations";

	}
}
