function popUp(){
  alert("Bienvenue chez nous !");
}

function changement(){
getElementsByTagName("body");

}
